import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-text-content.ts';